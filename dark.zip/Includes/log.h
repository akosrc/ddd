
// ================================================================================
// Source archive verified by @imguisource_bot
// Channels:
// - ImGui Source (t.me/ImGui_Source_FIXNEY)
// - shit src 🧨 (t.me/il2cpp_src)
// ================================================================================

//
// Created by Perfare on 2020/7/4.
//

#ifndef RIRU_IL2CPPDUMPER_LOG_H
#define RIRU_IL2CPPDUMPER_LOG_H

#include <android/log.h>

#define LOG_TAG "N1kryyy123"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

#endif //RIRU_IL2CPPDUMPER_LOG_H
