//LUCFER @krro6
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function QDevKit.FilePicker.UnInitialize
// (Final, Native, Static, Public, BlueprintCallable)

void UFilePicker::UnInitialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FilePicker.UnInitialize");

	UFilePicker_UnInitialize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.FilePicker.OpenFilePicker
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 InParamJson                    (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFilePicker::OpenFilePicker(const struct FString& InParamJson)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FilePicker.OpenFilePicker");

	UFilePicker_OpenFilePicker_Params params;
	params.InParamJson = InParamJson;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FilePicker.Initialize
// (Final, Native, Public, BlueprintCallable)

void UFilePicker::Initialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FilePicker.Initialize");

	UFilePicker_Initialize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.FilePicker.GetInstance
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UFilePicker*             ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UFilePicker* UFilePicker::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FilePicker.GetInstance");

	UFilePicker_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// DelegateFunction QDevKit.FilePicker.FileSelectionCompleteDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// struct FString                 ResultJson                     (Parm, ZeroConstructor)

void UFilePicker::FileSelectionCompleteDelegate__DelegateSignature(const struct FString& ResultJson)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction QDevKit.FilePicker.FileSelectionCompleteDelegate__DelegateSignature");

	UFilePicker_FileSelectionCompleteDelegate__DelegateSignature_Params params;
	params.ResultJson = ResultJson;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.FirebaseHelper.SetFirebaseDebugMode
// (Final, Native, Public)
// Parameters:
// bool                           bEnable                        (Parm, ZeroConstructor, IsPlainOldData)

void UFirebaseHelper::SetFirebaseDebugMode(bool bEnable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.SetFirebaseDebugMode");

	UFirebaseHelper_SetFirebaseDebugMode_Params params;
	params.bEnable = bEnable;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.FirebaseHelper.SetConsent
// (Final, Native, Public, HasOutParms)
// Parameters:
// TMap<int, int>                 InConsent                      (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UFirebaseHelper::SetConsent(TMap<int, int> InConsent)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.SetConsent");

	UFirebaseHelper_SetConsent_Params params;
	params.InConsent = InConsent;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.FirebaseHelper.IsNotificationLaunchApp
// (Final, Native, Public)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFirebaseHelper::IsNotificationLaunchApp()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.IsNotificationLaunchApp");

	UFirebaseHelper_IsNotificationLaunchApp_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FirebaseHelper.IsFirebaseDebugMode
// (Final, Native, Public)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UFirebaseHelper::IsFirebaseDebugMode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.IsFirebaseDebugMode");

	UFirebaseHelper_IsFirebaseDebugMode_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FirebaseHelper.GetNotificationLaunchAppExtraData
// (Final, Native, Public)
// Parameters:
// struct FString                 InKey                          (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UFirebaseHelper::GetNotificationLaunchAppExtraData(const struct FString& InKey)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.GetNotificationLaunchAppExtraData");

	UFirebaseHelper_GetNotificationLaunchAppExtraData_Params params;
	params.InKey = InKey;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FirebaseHelper.GetInstance
// (Final, Native, Static, Public)
// Parameters:
// class UFirebaseHelper*         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UFirebaseHelper* UFirebaseHelper::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.GetInstance");

	UFirebaseHelper_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FirebaseHelper.GetFIRInstallId
// (Final, Native, Public)
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UFirebaseHelper::GetFIRInstallId()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.GetFIRInstallId");

	UFirebaseHelper_GetFIRInstallId_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FirebaseHelper.GetFIRAppInstanceId
// (Final, Native, Public)
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UFirebaseHelper::GetFIRAppInstanceId()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.GetFIRAppInstanceId");

	UFirebaseHelper_GetFIRAppInstanceId_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FirebaseHelper.GetFCMToken
// (Final, Native, Public)
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UFirebaseHelper::GetFCMToken()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.GetFCMToken");

	UFirebaseHelper_GetFCMToken_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FirebaseHelper.ConsumeNotificationLaunchApp
// (Final, Native, Public)

void UFirebaseHelper::ConsumeNotificationLaunchApp()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseHelper.ConsumeNotificationLaunchApp");

	UFirebaseHelper_ConsumeNotificationLaunchApp_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.FirebaseRemoteConfigImpl.GetStatus
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// EQFirebaseRemoteConfigStatus   ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EQFirebaseRemoteConfigStatus UFirebaseRemoteConfigImpl::GetStatus()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseRemoteConfigImpl.GetStatus");

	UFirebaseRemoteConfigImpl_GetStatus_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FirebaseRemoteConfigImpl.GetRemoteConfig
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ConfigNameToQuery              (Parm, ZeroConstructor)
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UFirebaseRemoteConfigImpl::GetRemoteConfig(const struct FString& ConfigNameToQuery)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseRemoteConfigImpl.GetRemoteConfig");

	UFirebaseRemoteConfigImpl_GetRemoteConfig_Params params;
	params.ConfigNameToQuery = ConfigNameToQuery;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.FirebaseRemoteConfigImpl.GetInstance
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UFirebaseRemoteConfigImpl* ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UFirebaseRemoteConfigImpl* UFirebaseRemoteConfigImpl::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.FirebaseRemoteConfigImpl.GetInstance");

	UFirebaseRemoteConfigImpl_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.LocationHelper.QueryLocation
// (Final, Native, Public)
// Parameters:
// int                            InTimeout                      (Parm, ZeroConstructor, IsPlainOldData)

void ULocationHelper::QueryLocation(int InTimeout)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.LocationHelper.QueryLocation");

	ULocationHelper_QueryLocation_Params params;
	params.InTimeout = InTimeout;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.LocationHelper.Initialize
// (Final, Native, Public)

void ULocationHelper::Initialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.LocationHelper.Initialize");

	ULocationHelper_Initialize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.LocationHelper.GetInstance
// (Final, Native, Static, Public)
// Parameters:
// class ULocationHelper*         ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ULocationHelper* ULocationHelper::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.LocationHelper.GetInstance");

	ULocationHelper_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.LocationHelper.Destroy
// (Final, Native, Public)

void ULocationHelper::Destroy()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.LocationHelper.Destroy");

	ULocationHelper_Destroy_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.PhotoAlbumHelper.UnRegisterScreenCaptureListener
// (Final, Native, Public)

void UPhotoAlbumHelper::UnRegisterScreenCaptureListener()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.PhotoAlbumHelper.UnRegisterScreenCaptureListener");

	UPhotoAlbumHelper_UnRegisterScreenCaptureListener_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.PhotoAlbumHelper.RegisterScreenCaptureListener
// (Final, Native, Public)
// Parameters:
// struct FString                 InScreenshotFolders            (Parm, ZeroConstructor)
// struct FString                 InScreenshotMimeTypes          (Parm, ZeroConstructor)

void UPhotoAlbumHelper::RegisterScreenCaptureListener(const struct FString& InScreenshotFolders, const struct FString& InScreenshotMimeTypes)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.PhotoAlbumHelper.RegisterScreenCaptureListener");

	UPhotoAlbumHelper_RegisterScreenCaptureListener_Params params;
	params.InScreenshotFolders = InScreenshotFolders;
	params.InScreenshotMimeTypes = InScreenshotMimeTypes;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.PhotoAlbumHelper.Initialize
// (Final, Native, Public)

void UPhotoAlbumHelper::Initialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.PhotoAlbumHelper.Initialize");

	UPhotoAlbumHelper_Initialize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.PhotoAlbumHelper.GetInstance
// (Final, Native, Static, Public)
// Parameters:
// class UPhotoAlbumHelper*       ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UPhotoAlbumHelper* UPhotoAlbumHelper::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.PhotoAlbumHelper.GetInstance");

	UPhotoAlbumHelper_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.PhotoAlbumHelper.GenerateImageFromAlbum
// (Final, Native, Public)
// Parameters:
// struct FString                 InFilePath                     (Parm, ZeroConstructor)
// struct FString                 InThumbFilePath                (Parm, ZeroConstructor)
// int                            InThumbnailWidth               (Parm, ZeroConstructor, IsPlainOldData)
// int                            InThumbnailHeight              (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InForceJPG                     (Parm, ZeroConstructor, IsPlainOldData)
// bool                           InOverride                     (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UPhotoAlbumHelper::GenerateImageFromAlbum(const struct FString& InFilePath, const struct FString& InThumbFilePath, int InThumbnailWidth, int InThumbnailHeight, bool InForceJPG, bool InOverride)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.PhotoAlbumHelper.GenerateImageFromAlbum");

	UPhotoAlbumHelper_GenerateImageFromAlbum_Params params;
	params.InFilePath = InFilePath;
	params.InThumbFilePath = InThumbFilePath;
	params.InThumbnailWidth = InThumbnailWidth;
	params.InThumbnailHeight = InThumbnailHeight;
	params.InForceJPG = InForceJPG;
	params.InOverride = InOverride;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.PhotoAlbumHelper.FetchAlbumImageInfo
// (Final, Native, Public)
// Parameters:
// int                            InStartIndex                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            InLimitNum                     (Parm, ZeroConstructor, IsPlainOldData)
// int                            InThumbWidth                   (Parm, ZeroConstructor, IsPlainOldData)
// int                            InThumbHeight                  (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 InThumbPath                    (Parm, ZeroConstructor)
// struct FString                 InExtraJson                    (Parm, ZeroConstructor)

void UPhotoAlbumHelper::FetchAlbumImageInfo(int InStartIndex, int InLimitNum, int InThumbWidth, int InThumbHeight, const struct FString& InThumbPath, const struct FString& InExtraJson)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.PhotoAlbumHelper.FetchAlbumImageInfo");

	UPhotoAlbumHelper_FetchAlbumImageInfo_Params params;
	params.InStartIndex = InStartIndex;
	params.InLimitNum = InLimitNum;
	params.InThumbWidth = InThumbWidth;
	params.InThumbHeight = InThumbHeight;
	params.InThumbPath = InThumbPath;
	params.InExtraJson = InExtraJson;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.StoreKit.RequestReview
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bForceOpenStoreInTestEnv       (Parm, ZeroConstructor, IsPlainOldData)

void UStoreKit::RequestReview(bool bForceOpenStoreInTestEnv)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.StoreKit.RequestReview");

	UStoreKit_RequestReview_Params params;
	params.bForceOpenStoreInTestEnv = bForceOpenStoreInTestEnv;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.StoreKit.OpenStorePage
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// struct FString                 storeParam                     (Parm, ZeroConstructor)

void UStoreKit::OpenStorePage(const struct FString& storeParam)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.StoreKit.OpenStorePage");

	UStoreKit_OpenStorePage_Params params;
	params.storeParam = storeParam;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.StoreKit.GetCountryCode
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FScriptDelegate         Callback                       (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UStoreKit::GetCountryCode(const struct FScriptDelegate& Callback)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.StoreKit.GetCountryCode");

	UStoreKit_GetCountryCode_Params params;
	params.Callback = Callback;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.SystemPermissionHelper.RequestPermissions
// (Final, Native, Public)
// Parameters:
// int                            InPermissionType               (Parm, ZeroConstructor, IsPlainOldData)
// int                            InRequestCode                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool USystemPermissionHelper::RequestPermissions(int InPermissionType, int InRequestCode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.SystemPermissionHelper.RequestPermissions");

	USystemPermissionHelper_RequestPermissions_Params params;
	params.InPermissionType = InPermissionType;
	params.InRequestCode = InRequestCode;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.SystemPermissionHelper.IsPermissionGranted
// (Final, Native, Public)
// Parameters:
// int                            InPermissionType               (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool USystemPermissionHelper::IsPermissionGranted(int InPermissionType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.SystemPermissionHelper.IsPermissionGranted");

	USystemPermissionHelper_IsPermissionGranted_Params params;
	params.InPermissionType = InPermissionType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.SystemPermissionHelper.Initialize
// (Final, Native, Public)

void USystemPermissionHelper::Initialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.SystemPermissionHelper.Initialize");

	USystemPermissionHelper_Initialize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.SystemPermissionHelper.GetPermissionStatus
// (Final, Native, Public)
// Parameters:
// int                            InPermissionType               (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int USystemPermissionHelper::GetPermissionStatus(int InPermissionType)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.SystemPermissionHelper.GetPermissionStatus");

	USystemPermissionHelper_GetPermissionStatus_Params params;
	params.InPermissionType = InPermissionType;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.SystemPermissionHelper.GetInstance
// (Final, Native, Static, Public)
// Parameters:
// class USystemPermissionHelper* ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class USystemPermissionHelper* USystemPermissionHelper::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.SystemPermissionHelper.GetInstance");

	USystemPermissionHelper_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.SystemPermissionHelper.AndroidShouldShowRequestPermissionRationale
// (Final, Native, Public)
// Parameters:
// struct FString                 InPermission                   (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool USystemPermissionHelper::AndroidShouldShowRequestPermissionRationale(const struct FString& InPermission)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.SystemPermissionHelper.AndroidShouldShowRequestPermissionRationale");

	USystemPermissionHelper_AndroidShouldShowRequestPermissionRationale_Params params;
	params.InPermission = InPermission;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.SystemPermissionHelper.AndroidRequestPermissions
// (Final, Native, Public)
// Parameters:
// struct FString                 InPermission                   (Parm, ZeroConstructor)
// int                            InRequestCode                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool USystemPermissionHelper::AndroidRequestPermissions(const struct FString& InPermission, int InRequestCode)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.SystemPermissionHelper.AndroidRequestPermissions");

	USystemPermissionHelper_AndroidRequestPermissions_Params params;
	params.InPermission = InPermission;
	params.InRequestCode = InRequestCode;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.SystemPermissionHelper.AndroidIsPermissionGranted
// (Final, Native, Public)
// Parameters:
// struct FString                 InPermission                   (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool USystemPermissionHelper::AndroidIsPermissionGranted(const struct FString& InPermission)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.SystemPermissionHelper.AndroidIsPermissionGranted");

	USystemPermissionHelper_AndroidIsPermissionGranted_Params params;
	params.InPermission = InPermission;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.SystemPermissionHelper.AndroidHasDefinePermission
// (Final, Native, Public)
// Parameters:
// struct FString                 InPermssionName                (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool USystemPermissionHelper::AndroidHasDefinePermission(const struct FString& InPermssionName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.SystemPermissionHelper.AndroidHasDefinePermission");

	USystemPermissionHelper_AndroidHasDefinePermission_Params params;
	params.InPermssionName = InPermssionName;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.TouchTransmission.UnInitialize
// (Final, Native, Static, Public, BlueprintCallable)

void UTouchTransmission::UnInitialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.TouchTransmission.UnInitialize");

	UTouchTransmission_UnInitialize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// DelegateFunction QDevKit.TouchTransmission.TransmissionCompleteDelegate__DelegateSignature
// (MulticastDelegate, Public, Delegate)
// Parameters:
// struct FString                 ResultJson                     (Parm, ZeroConstructor)

void UTouchTransmission::TransmissionCompleteDelegate__DelegateSignature(const struct FString& ResultJson)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("DelegateFunction QDevKit.TouchTransmission.TransmissionCompleteDelegate__DelegateSignature");

	UTouchTransmission_TransmissionCompleteDelegate__DelegateSignature_Params params;
	params.ResultJson = ResultJson;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.TouchTransmission.Initialize
// (Final, Native, Public, BlueprintCallable)

void UTouchTransmission::Initialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.TouchTransmission.Initialize");

	UTouchTransmission_Initialize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function QDevKit.TouchTransmission.HandleReceivedPakFiles
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 InParamJson                    (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UTouchTransmission::HandleReceivedPakFiles(const struct FString& InParamJson)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.TouchTransmission.HandleReceivedPakFiles");

	UTouchTransmission_HandleReceivedPakFiles_Params params;
	params.InParamJson = InParamJson;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.TouchTransmission.GetTransmissionRawJsonContent
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UTouchTransmission::GetTransmissionRawJsonContent()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.TouchTransmission.GetTransmissionRawJsonContent");

	UTouchTransmission_GetTransmissionRawJsonContent_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function QDevKit.TouchTransmission.GetInstance
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UTouchTransmission*      ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UTouchTransmission* UTouchTransmission::GetInstance()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function QDevKit.TouchTransmission.GetInstance");

	UTouchTransmission_GetInstance_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


}

