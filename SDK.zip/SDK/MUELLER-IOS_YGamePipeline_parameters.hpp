#pragma once

//LUCFER @krro6
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function YGamePipeline.YGamePipelineHelper.SendDataWithKey
struct UYGamePipelineHelper_SendDataWithKey_Params
{
	struct FString                                     MsgKey;                                                   // (Parm, ZeroConstructor)
	TArray<unsigned char>                              Data;                                                     // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function YGamePipeline.YGamePipelineHelper.SendData
struct UYGamePipelineHelper_SendData_Params
{
	struct FString                                     MsgInfo;                                                  // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function YGamePipeline.YGamePipelineHelper.Release
struct UYGamePipelineHelper_Release_Params
{
};

// Function YGamePipeline.YGamePipelineHelper.RecvdDataWithKeyTest
struct UYGamePipelineHelper_RecvdDataWithKeyTest_Params
{
	struct FString                                     MsgKey;                                                   // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function YGamePipeline.YGamePipelineHelper.RecvDataTest
struct UYGamePipelineHelper_RecvDataTest_Params
{
	struct FString                                     MsgInfo;                                                  // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function YGamePipeline.YGamePipelineHelper.Log
struct UYGamePipelineHelper_Log_Params
{
	struct FString                                     LogInfo;                                                  // (Parm, ZeroConstructor)
};

// Function YGamePipeline.YGamePipelineHelper.IsConnected
struct UYGamePipelineHelper_IsConnected_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function YGamePipeline.YGamePipelineHelper.Init
struct UYGamePipelineHelper_Init_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function YGamePipeline.YGamePipelineHelper.Get
struct UYGamePipelineHelper_Get_Params
{
	class UYGamePipelineHelper*                        ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

